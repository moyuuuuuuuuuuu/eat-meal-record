/*
 Navicat Premium Data Transfer

 Source Server         : 220.154.128.222 dev64 33306
 Source Server Type    : MySQL
 Source Server Version : 80043
 Source Host           : 220.154.128.222:33306
 Source Schema         : dev64_533467121728905216

 Target Server Type    : MySQL
 Target Server Version : 80043
 File Encoding         : 65001

 Date: 26/02/2026 10:20:30
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for drp_unit
-- ----------------------------
DROP TABLE IF EXISTS `drp_unit`;
CREATE TABLE `drp_unit`
(
    `id`             bigint                                                        NOT NULL AUTO_INCREMENT COMMENT '主键id',
    `area_id`        bigint                                                        NULL     DEFAULT NULL COMMENT '区域id',
    `unit_id`        bigint                                                        NOT NULL COMMENT '计量单位id',
    `unit_name`      varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '计量单位名称',
    `rate`           decimal(20, 6)                                                NOT NULL DEFAULT 0.000000 COMMENT '换算比率(换算成g)',
    `weigh_type`     int                                                           NOT NULL DEFAULT 1 COMMENT '单位类型(1-按份,2-称重)',
    `del_flag`       int                                                           NOT NULL DEFAULT 2 COMMENT '删除标识(1删除,2正常)',
    `revision`       int                                                           NOT NULL DEFAULT 0 COMMENT '乐观锁',
    `crby`           varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci  NOT NULL DEFAULT '' COMMENT '创建人',
    `crtime`         timestamp                                                     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `upby`           varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci  NOT NULL DEFAULT '' COMMENT '更新人',
    `uptime`         timestamp                                                     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    `third_party_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL     DEFAULT NULL COMMENT '三方ID',
    PRIMARY KEY (`id`) USING BTREE,
    INDEX `index_unit_id` (`unit_id`) USING BTREE,
    INDEX `index_area_id` (`area_id`) USING BTREE
) ENGINE = InnoDB
  AUTO_INCREMENT = 9
  CHARACTER SET = utf8mb4
  COLLATE = utf8mb4_unicode_ci COMMENT = '计量单位表'
  ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of drp_unit
-- ----------------------------
INSERT INTO `drp_unit`
VALUES (1, NULL, 74330978029408256, '斤', 500.000000, 2, 2, 0, '', '2024-08-30 15:02:37', '', '2024-08-30 15:02:38',
        NULL);
INSERT INTO `drp_unit`
VALUES (2, NULL, 74362936302243840, '公斤', 1000.000000, 2, 2, 0, '', '2024-08-30 15:02:37', '', '2024-08-30 15:02:38',
        NULL);
INSERT INTO `drp_unit`
VALUES (3, NULL, 74362972037713920, '箱', 0.000000, 1, 2, 0, '', '2024-08-30 15:02:37', '', '2024-08-30 15:02:37',
        NULL);
INSERT INTO `drp_unit`
VALUES (4, NULL, 74362992036155392, '瓶', 0.000000, 1, 2, 0, '', '2024-08-30 15:02:37', '', '2024-08-30 15:02:37',
        NULL);
INSERT INTO `drp_unit`
VALUES (5, NULL, 74363013850730496, '桶', 0.000000, 1, 2, 0, '', '2024-08-30 15:02:37', '', '2024-08-30 15:02:37',
        NULL);
INSERT INTO `drp_unit`
VALUES (6, NULL, 74363048172720128, '袋', 0.000000, 1, 2, 0, '', '2024-08-30 15:02:37', '', '2024-08-30 15:02:37',
        NULL);
INSERT INTO `drp_unit`
VALUES (7, NULL, 74363068041138176, '盒', 0.000000, 1, 2, 0, '', '2024-08-30 15:02:37', '', '2024-08-30 15:02:37',
        NULL);
INSERT INTO `drp_unit`
VALUES (8, NULL, 454138760464961541, '个', 0.000000, 1, 2, 0, '', '2024-08-30 15:02:37', '', '2024-08-30 15:02:37',
        NULL);

SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO `eat_clear`.`units` (`id`, `name`, `type`, `desc`, `created_at`, `updated_at`, `delete_at`)
VALUES (1, 'g', 'weight', '克', '2026-02-03 21:33:43', '2026-02-03 21:33:43', NULL),
       (2, 'kg', 'weight', '千克', '2026-02-03 21:33:43', '2026-02-03 21:33:43', NULL),
       (3, '个', 'count', '个', '2026-02-03 21:33:43', '2026-02-03 21:33:43', NULL),
       (4, '片', 'count', '片', '2026-02-03 21:33:43', '2026-02-03 21:33:43', NULL),
       (5, '碗', 'count', '中碗', '2026-02-03 21:33:43', '2026-02-03 21:33:43', NULL),
       (6, '杯', 'volume', '杯', '2026-02-03 21:33:43', '2026-02-03 21:33:43', NULL),
       (7, 'ml', 'volume', '毫升', '2026-02-03 21:33:43', '2026-02-03 21:33:43', NULL),
       (8, '份', 'service', '一份', '2026-02-03 21:33:43', '2026-02-03 21:33:43', NULL),
       (9, '斤', 'weight', '500g', '2026-02-03 21:33:43', '2026-02-03 21:33:43', NULL),
       (10, '箱', 'package', '', '2026-02-03 21:33:43', '2026-02-03 21:33:43', NULL),
       (11, '瓶', 'count', '', '2026-02-03 21:33:43', '2026-02-03 21:33:43', NULL),
       (12, '桶', 'count', '', '2026-02-03 21:33:43', '2026-02-03 21:33:43', NULL),
       (13, '袋', 'package', '', '2026-02-03 21:33:43', '2026-02-03 21:33:43', NULL),
       (14, '盒', 'package', '', '2026-02-03 21:33:43', '2026-02-03 21:33:43', NULL)
;
